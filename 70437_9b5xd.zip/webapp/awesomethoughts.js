var awesomeThoughts = " I am [simi]and I am AWEOME!"
console.log(awesomeThoughts);